function y = cepfeatures(s,N,deltaN,Fs,Q)
%  cepfeatures --> Feature extraction for HMM recognizer.
%
%  <Synopsis>
%    y = cepfeatures(s,N,deltaN,Fs,Q)
%
%  <Description>
%    A frame based analysis of the speech signal, s, is performed to
%    give observation vectors (columns of y), which can be used to train
%    HMMs for speech recognition.
%
%    The speech signal is blocked into frames of N samples, and
%    consecutive frames are spaced deltaN samples apart. Each frame is
%    multiplied by an N-sample Hamming window, and CEzP analysis
%    is performed.  
%    The result is the first half of an observation vector, 
%    the second half is the differenced cepstral coefficients 
%    used to add dynamic information.
%    Thus, the returned argument y is an 2Q-by-T matrix, where T is the
%    number of frames.

%    INPUT
%    s: signal, N: window size, deltaN: window shift in samples, Fs:sampling freq (for plotting), Q: No of ceps  
% 
%
Ns = length(s);                         % Signal length.
T  = 1 + fix((Ns-N)/deltaN);            % No. of frames.
%
gamma   = zeros(Q,1);
win_sin=sin(pi*((1:N ) -1)/N)';
win_gamma = 1 + (Q/2)*sin(pi/Q*(1:Q)'); % Cepstral window function.
for t = 1:T,                           % Loop frames.
    % Block into frames.
    idx = (deltaN*(t-1)+1):(deltaN*(t-1)+N);
    % Window frame.
    sw = s(idx).*win_sin; 
    NFFT = 2^nextpow2(N); % Next power of 2 from length of y
    Y = fft(sw,NFFT)/N;
    y = ifft(log(abs(Y)),NFFT,'symmetric');
    gamma(:,t) = ( abs(y(2:(Q+1))) + abs( y((end-1):-1:(end-Q)) ) ) .*win_gamma; 
end
% Time differenced weighted cepstral sequence.
delta_gamma = gradient(gamma);
% Observation vectors.
y = [gamma; delta_gamma];










