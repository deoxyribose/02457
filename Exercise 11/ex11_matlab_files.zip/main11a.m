% COURSE 02457 EXERCISE 11 
% SPEECH PROCESSING
% Lars Kai Hansen (c) 2001, 2012
%
%
clear,
% Initialization
N = 320;       %Windows length
deltaN = 80;   % Window spacing
Fs=10000;
Q = 12;        % Cepstral coefficients
% load letter database
load letters
% extract training letters
s1=letters.s1;   % extract letter s
o1=letters.o1;   % extract letter o
f1=letters.f1;   % extract letter f
y_s1= cepfeatures(s1,N,deltaN,Fs,Q);
y_o1= cepfeatures(o1,N,deltaN,Fs,Q);
y_f1= cepfeatures(f1,N,deltaN,Fs,Q);
%extract test letters
s2=letters.s2;
o2=letters.o2;
f2=letters.f2;
y_s2= cepfeatures(s2,N,deltaN,Fs,Q);
y_o2= cepfeatures(o2,N,deltaN,Fs,Q);
y_f2= cepfeatures(f2,N,deltaN,Fs,Q);
Ns1=size(y_s1,2);
No1=size(y_o1,2);
Nf1=size(y_f1,2);
Ns2=size(y_s2,2);
No2=size(y_o2,2);
Nf2=size(y_f2,2);

%%%%%%% SHOW letters
figure(1),
subplot(2,2,1),plot(s1),title('s1')
subplot(2,2,2),plot(o1),title('o1')
subplot(2,2,3),plot(o2),title('o2')
subplot(2,2,4),plot(f1),title('f1')
%disp('IF YOU HAVE SOUND ACCESS: LISTEN TO s1')
%soundsc(s1,10000)
%%%%%%%%%% SHOW SPECTROGRAMS
figure(2),
subplot(2,2,1),specgram(s1,[],8000),title('s1')
subplot(2,2,2),specgram(o1,[],8000),title('o1')
subplot(2,2,3),specgram(o2,[],8000),title('o2')
subplot(2,2,4),specgram(f1,[],8000),title('f1')

%train pca
x1=[y_s1';y_o1';y_f1']';
xmean1=mean(x1,2);
z1=x1-repmat(xmean1,1,No1+Ns1+Nf1);
scale1=std(z1,0,2);
z1=diag(1./scale1)*z1;
x2=[y_s2';y_o2';y_f2']';
xmean2=mean(x2,2);
z2=x2-repmat(xmean2,1,No2+Ns2+Nf2);
scale2=std(z2,0,2);
z2=diag(1./scale2)*z2;
figure(3)
%fh=figure(3),
%temp = get(fh,'position');
%temp = [1 300 400 600];
%set(fh,'position',temp);  

hold off
subplot(2,1,1), imagesc(z1),title('TRAINING DATA'),colormap('gray')
subplot(2,1,2), imagesc(z2),title('TEST DATA'),colormap('gray')

% Project the features
[U,D,V]=svd(z1);
p11=U(:,1)'*z1;
p21=U(:,2)'*z1;
p12=U(:,1)'*z2;
p22=U(:,2)'*z2;

figure(4),
%fh=figure(4),
%temp = get(fh,'position');
%temp = [310 300 610 600];
%set(fh,'position',temp);  

subplot(2,1,1),title('TRAINING DATA')
for j=1:Ns1,
   text(p11(j),p21(j),'s'),
   hold on
end
for j=1:No1,
   text(p11((Ns1+j)),p21((Ns1+j)),'o')
   hold on
end
for j=1:Nf1,
   text(p11((Ns1+No1+j)),p21((Ns1+No1+j)),'f')
   hold on
end
plot(p11,p21,'b.')

subplot(2,1,2), title('TEST DATA')
for j=1:Ns2,
   text(p12(j),p22(j),'s'),
   hold on
end
for j=1:No2,
   text(p12((Ns2+j)),p22((Ns2+j)),'o')
   hold on
end
for j=1:Nf2,
   text(p12((Ns2+No2+j)),p22((Ns2+No2+j)),'f')
   hold on
end
plot(p12,p22,'g.')