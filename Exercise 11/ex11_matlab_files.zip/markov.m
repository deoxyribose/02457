function a=markov(seq,K);
%
% function a=markov(seq,K);
%
%
N=length(seq)
ht=seq(1:(end-1)) + K*(seq(2:end)-1);
n=hist(ht,1:(K*K));
a=reshape(n,K,K);
asum=sum(a,2);
a=a.*repmat(1./asum,1,K);