function j=getint(p)
%
% draws a random integer from distribution p
%
j=min(find(rand < cumsum(p)));
