clear                           % Create HMM Learning Curves

maxiter= 100;                    % max no. of EM updates
tol= 10^-5;                     % tolerance

L = 15000;                      % Max no of examples
S = 4;                          % no of states in data generation
K = 5;                          % dimension of observation space% no of observations in output space
Psss = 0.95;                    % probability to stay in the same state
Pses = 0.75;                    % probability of having the same emmision as the state
noStates = 1:13;                % no of states to test
noModels = 5;                   % no of times to estimate the model 

A = diag(repmat(Psss,1,S));     % generate pseudo random transition matrix
for i=1:S                       % where prob of staying in the same state is Psss
  a = rand(1,S-1);              % 
  a = (1-Psss)*a/sum(a);        %
  A(A(:,i)==0,i) = a';          %
end                             %

sB = min([S,K]);                % generate pseudo random emmision matrix
B = zeros(K,S);                 %
for i=1:sB;B(i,i)=Pses;end      %
for i=1:S                       %
  if i>K                        %
    a = rand(1,K);              %
  else                          %
    a = rand(1,K-1);            %
  end                           %
  a = (1-Pses)*a/sum(a);        %
  B(B(:,i)==0,i) = a';          %
end                             %
B = B./repmat(sum(B),K,1);      %

PI_ = ones(S,1)/S;              % starting state has uniform distribution


[obs,stat] = hmmgen(A,B,PI_,L); % generate data
[obsT,statT]=hmmgen(A,B,PI_,L); % generate test data

figure(1)
hold off
i=0;
for nS=500%[100,200,500,1000,2000,5000,10000] % number of samples used for training
  i=i+1
  j=0;
  trainSamples = obs(1:nS);

  for nStat=noStates
    j=j+1;
    
    for k=1:noModels
    
      [Atr,Btr,PItr,LLtr] = hmmfb({trainSamples},nStat,K,0,maxiter,tol);
      disp(['No of hidden states = ',int2str(nStat),' Model no = ',int2str(k)])
      rea(i,j,k) = hmmlogp(obs(1:nS),Atr,Btr,PItr)/nS;
      res(i,j,k) = hmmlogp(obsT,Atr,Btr,PItr)/L;
      
        figure(1)
        
        colormap('gray')
        subplot(2,4,1);image(A*255);xlabel('input state');ylabel('output state');title('original transition matrix')
        subplot(2,4,2);image(B'*255);ylabel('state');xlabel('emmision');title('original emmision matrix')
        subplot(2,2,2);
                hold on
                plot(noStates(1:j),rea(1,:,k), 'k.');xlabel('no of states');
        ylabel(['Likelihood (Model no ',int2str(k),')']);title('Training Set')
            grid
        subplot(2,4,5);image(Atr*255);xlabel('input state');ylabel('output state');title('estimated transition matrix')
        subplot(2,4,6);image(Btr'*255);ylabel('state');xlabel('emmision');title('estimated emmision matrix')
        subplot(2,2,4);
                hold on
                plot(noStates(1:j),res(1,:,k), 'k.');xlabel('no of states');
        ylabel(['Likelihood (Model no ',int2str(k),')']);title('Test Set')
         grid
      drawnow

      if ((nStat==5) & (k==1))
        doNothing = 1; % PUT BREAK POINT HERE TO INSPECT 8-STATE
      end
      
    end
  end
end


figure(2)

subplot(2,4,1);image(A*255);xlabel('input state');ylabel('output state');title('original transition matrix')
 colormap('gray')
subplot(2,4,2);image(B'*255);ylabel('state');xlabel('emmision');title('original emmision matrix')
 colormap('gray')
subplot(2,2,2);plot(noStates(1:j),sum(rea,3)'/k, 'k.');xlabel('no of states');
ylabel('likelihood');title('Mean performance on training Set')
grid
subplot(2,4,5);image(Atr*255);xlabel('input state');ylabel('output state');title('estimated transition matrix')
 colormap('gray')
subplot(2,4,6);image(Btr'*255);ylabel('state');xlabel('emmision');title('estimated emmision matrix')
 colormap('gray')
subplot(2,2,4);plot(noStates(1:j),sum(res,3)'/k, 'k.');
xlabel('no of states');ylabel('likelihood');title('Mean performance on test Set')
grid

figure(3)
subplot(2,1,1)
plot(noStates(1:j),squeeze(rea)', 'k.');xlabel('no of states');ylabel('likelihood');title('Test Set')
title('likelihood for the train set for 5 runs')
grid
bigfig
subplot(2,1,2)
plot(noStates(1:j),squeeze(res)', 'k.');xlabel('no of states');ylabel('likelihood');title('Test Set')
title('likelihood for the test set for 5 runs')
grid
bigfig
