function [y,x] = hmmgen(A,B,pi1,L)
%  hmmgen --> generate state and observation sequence from
%  HMM with parameters A,B,pi1 
%
%  <Synopsis>
%    function [y,x] = hmmgen(A,B,pi1,L)
%
%  <Description>
%    The function draws L states from the Markov chain with transition matrix 
%    A, starting in a state with probability pi1, and then generates observations
%    according to B.
%    The outputs are the observations y and the states x
%
%
%  <Revision>
%    LK. Hansen, IMM, Technical University of Denmark
%
%    Last revised: November 19, 2001
%-----------------------------------------------------------------------
x=zeros(L,1);
y=zeros(L,1);
x(1)=getint(pi1);
y(1)=getint(B(:,x(1)));
for t=2:L,
   x(t)=getint(A(:,x(t-1)));
   y(t)=getint(B(:,x(t)));
end
%-----------------------------------------------------------------------
% End of function hmmgen
%-----------------------------------------------------------------------
