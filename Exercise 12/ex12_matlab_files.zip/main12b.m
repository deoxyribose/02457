% Exercise 12
%  main12b.m for speech recognition
% 
% Training and testing the combined system

  % generate codebook
  load ti46; data = ti46.case(27:36);
  for (i=1:10)
    train{i} = data{i}(1:10);
  end
  
  N = 320; deltaN = 80; M = 12; Q = 12; Kmax = 16;
  
  [cb,K,T,dist] = hmmcodebook(train,N,deltaN,M,Q,Kmax); 
  
  S = 5; maxiter = 5000; tol = 1e-3;
  
  
  [A_m,B_m,pi_m,loglike_m] = hmmtrain(train,N,deltaN,M,Q,cb,S,maxiter,tol); 
  
  figure(2),
  subplot(2,1,1)
  plot(loglike_m{1}),title('LIKELIHOOD FOR TRAINING "ONE"') 
  subplot(2,1,2)
  plot(loglike_m{10}),title('LIKELIHOOD FOR TRAINING "ZERO"') 
  figure(3)
  subplot(3,1,1)
  bar3(A_m{1}),title('TRANSITION MATRIX FOR "ONE"')
  subplot(3,1,2)
  bar3(B_m{1}), title('EMISSION PROBABILITY MATRIX FOR "ONE"')
  subplot(6,1,6)
  bar(pi_m{1}), title('INITIAL STATE PROBABILITIES FOR "ONE"')
  figure(4)
  subplot(3,1,1)
  bar3(A_m{10}),title('TRANSITION MATRIX FOR "ZERO"')
  subplot(3,1,2)
  bar3(B_m{6}), title('EMISSION PROBABILITY MATRIX FOR "ZERO"')
  subplot(6,1,6)
  bar(pi_m{10}), title('INITIAL STATE PROBABILITIES FOR "ZERO"')
  
  % use model
   [logp,guess] = hmmrecog(data{1}(12),A_m,B_m,pi_m,cb,N,deltaN,M,Q); 
  
  %normalize probabilities with uniform prior
  figure(5),
  subplot(2,1,1),plot([1:9,0],logp,'o'),title('LOG PROBABILITY OF SPOKEN DIGIT')
  pp=exp(logp);
  pp=pp/sum(pp);
  subplot(2,1,2)
  bar([1:9,0],pp),title('PROBABILITY OF SPOKEN DIGITS')
  
  
 [logp,guess] = hmmrecog(data{5}(12),A_m,B_m,pi_m,cb,N,deltaN,M,Q); 
  
  %normalize probabilities with uniform prior
  figure(6),
  subplot(2,1,1),plot([1:9,0],logp,'o'),title('LOG PROBABILITY OF SPOKEN DIGIT')
  pp=exp(logp);
  pp=pp/sum(pp);
  subplot(2,1,2)
  bar([1:9,0],pp),title('PROBABILITY OF SPOKEN DIGITS')